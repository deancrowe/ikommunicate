// IMPORTANT: DON'T MODIFY OR DELETE THE CODE OUTSIDE THE USERS SECTIONS

/*
   VARIABLES AVAILABLE

   Below are the variables available. The user can activate them:

   1) Adding it to the user array variable (section USER CODE 1) and
   2) Add its gauge (section USER CODE 2)

   Current outside air temperature                                             // Environment
   Current outside air ambient pressure
   Current water temperature
   Depth below keel
   Depth below transducer
   Depth from surface
   Apparent wind angle, negative to port
   Apparent wind speed

   Course over ground (true)                                                   // Navigation
   Heading (magnetic)
   Longitude
   Latitude
   Speed over ground
   Speed through the water
*/

// ****************************************************************************** USER CODE 1
// Here the user can add or delete his/her variables. In addition, the user must add or remove the corresponding gauge in
// the section USER CODE 2
var variableUser=[
                   "Depth below transducer",
				   "Depth below keel",
				   "Depth below surface",
                   "Apparent wind angle",
                   "Apparent wind speed",
                   "Heading (magnetic)",
                   "Course over ground (true)",
				   "Speed over ground",
                   "Speed through the water"];
// ****************************************************************************** END USER CODE 1

//Creating the guages
function gaugesUser() {
  gauge = undefined;
  document.getElementById("gauge").innerHTML = "";
  $("#gauge").hide();
  $("#display").show();

  // **************************************************************************** USER CODE 2

  // The gauges must be in the same order as they were defined in the section USER CODE 1
  // variableUser[0] refers to the first variable defined in USER CODE 1, variableUser[1] to second, etc.
  
  // If there is no gauge for a variable, only define its units as in the examples

  if(variableCurrentLabel==variableUser[0]) {                                   // First user variable
    $("#display").hide();
    $("#gauge").show();
    gauge = new JustGage({
      id: "gauge",
      value : 0,
      min: 0,
      max: 100,
      decimals: 1,
      title: "Depth Below Transducer",
      titleFontColor: "#2D4259",
      label: "Meters",
      gaugeWidthScale: 0.6,
      customSectors: [{
        color : "#ff0000",
        lo : 0,
        hi : 10
      },{
        color : "#00ff00",
        lo : 10,
        hi : 100
      }],
    });
  }
  else if(variableCurrentLabel==variableUser[1]) {                               // Second user variable
    $("#display").hide();
    $("#gauge").show();
    gauge = new JustGage({
      id: "gauge",
      value : 0,
      min: 0,
      max: 100,
      decimals: 1,
      title: "Depth Below Keel",
      titleFontColor: "#2D4259",
      label: "Meters",
      gaugeWidthScale: 0.6,
      customSectors: [{
        color : "#ff0000",
        lo : 0,
        hi : 10
      },{
        color : "#00ff00",
        lo : 10,
        hi : 100
      }],
    });
  }
  else if(variableCurrentLabel==variableUser[2]) {                               // Third user variable
    $("#display").hide();
    $("#gauge").show();
    gauge = new JustGage({
      id: "gauge",
      value : 0,
      min: 0,
      max: 100,
      decimals: 1,
      title: "Depth Below Surface",
      titleFontColor: "#2D4259",
      label: "Meters",
      gaugeWidthScale: 0.6,
      customSectors: [{
        color : "#ff0000",
        lo : 0,
        hi : 10
      },{
        color : "#00ff00",
        lo : 10,
        hi : 100
      }],
    });
  }
  else if(variableCurrentLabel==variableUser[3])                                // etc.
    variableUnits = "Radians";
  else if(variableCurrentLabel==variableUser[4])
    variableUnits = "m/s";
  else if(variableCurrentLabel==variableUser[5])
    variableUnits = "Radians";
  else if(variableCurrentLabel==variableUser[6])
    variableUnits = "Radians";
  else if(variableCurrentLabel==variableUser[7]) {                               
    $("#display").hide();
    $("#gauge").show();
    gauge = new JustGage({
      id: "gauge",
      value : 0,
      min: 0,
      max: 40,
      decimals: 1,
      title: "Boat Speed (Over Ground)",
      titleFontColor: "#2D4259",
      label: "m/s",
      gaugeWidthScale: 0.6,
      customSectors: [{
        color : "#00ff00",
        lo : 0,
        hi : 20
      },{
        color : "#ff0000",
        lo : 20,
        hi : 40
      }],
    });
  }
  else if(variableCurrentLabel==variableUser[8]) {                               
    $("#display").hide();
    $("#gauge").show();
    gauge = new JustGage({
      id: "gauge",
      value : 0,
      min: 0,
      max: 40,
      decimals: 1,
      title: "Boat Speed (Through Water)",
      titleFontColor: "#2D4259",
      label: "m/s",
      gaugeWidthScale: 0.6,
      customSectors: [{
        color : "#00ff00",
        lo : 0,
        hi : 20
      },{
        color : "#ff0000",
        lo : 20,
        hi : 40
      }],
    });
  }
  
  // **************************************************************************** END USER CODE 2

  // Define initial status of the buttons
  document.getElementById('buttonGaugeSettings').innerHTML = "Gauge Settings";
  document.getElementById("settings").style.display = "none"
//localStorage.clear();
  if(gauge!==undefined) {
    document.getElementById('buttonGaugeSettings').disabled = false;
    if(localStorage.getItem(variableCurrentLabel.replace(/\s/g,"")+"_max")) {
      gauge.config.max = localStorage.getItem(variableCurrentLabel.replace(/\s/g,"")+"_max");
      document.getElementById("gaugeMaximumValue").value = gauge.config.max;
      gauge.refresh(0,gauge.config.max,gauge.config);
    }
  }
  else
    document.getElementById('buttonGaugeSettings').disabled = true;
}
